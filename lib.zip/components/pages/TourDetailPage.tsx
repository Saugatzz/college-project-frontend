'use client';
import { useEffect, useState }         from 'react';
import Link                 from 'next/link';
import type { Tour }        from '@/types/tour';
import DetailHero           from '@/components/detail/DetailHero';
import PhotoGallery         from '@/components/detail/PhotoGallery';
import Itinerary            from '@/components/detail/Itinerary';
import Highlights           from '@/components/detail/Highlights';
import IncludesExcludes     from '@/components/detail/IncludeExcludes';
import BookingSidebar       from '@/components/detail/BookingSidebar';
import SimilarTours         from '@/components/detail/SimilarTours';
import api                  from '@/lib/api/api';

function SectionTitle({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <h2
      id={id}
      className="font-serif text-[1.55rem] font-semibold text-ink mb-5 flex items-center gap-3
        after:content-[''] after:flex-1 after:h-px after:bg-gradient-to-r
        after:from-sky-mid/35 after:to-transparent"
    >
      {children}
    </h2>
  );
}

// SimilarTours now receives tours from outside rather than filtering TOURS
interface Props {
  tour:         Tour;
  similarTours?: Tour[];
}

export default function TourDetailPage({ tour, similarTours = [] }: Props) {
  const [selectedAddons, setSelectedAddons] = useState<Record<number, number>>({});

  useEffect(() => {
    // Fire-and-forget: the axios client already attaches the JWT if the
    // person is logged in, and the backend silently no-ops for guests
    // (OptionalJwtAuthGuard). Never surfaces an error to the visitor.
    if (tour?.id) {
      api.post(`/packages/${tour.id}/interact`, { type: 'view' }).catch(() => {});
    }
  }, [tour?.id]);


  const toggleAddon = (index: number, price: number, checked: boolean) => {
    setSelectedAddons(prev => {
      const next = { ...prev };
      if (checked) next[index] = price;
      else delete next[index];
      return next;
    });
  };

  const total =
    tour.price + Object.values(selectedAddons).reduce((a, b) => a + b, 0);

  return (
    <div>
      <DetailHero tour={tour} />

      {/* Breadcrumb */}
      <nav
        className="px-4 md:px-12 py-3.5 bg-mist border-b border-sky-mid/15"
        aria-label="Breadcrumb"
      >
        <ol className="flex items-center gap-2 list-none text-[0.8rem] text-pebble flex-wrap">
          <li>
            <Link href="/" className="text-sky-accent no-underline hover:underline">
              Home
            </Link>
          </li>
          <li className="text-pebble" aria-hidden="true">›</li>
          <li>
            <Link href="/" className="text-sky-accent no-underline hover:underline">
              Tours
            </Link>
          </li>
          <li className="text-pebble" aria-hidden="true">›</li>
          <li aria-current="page" className="text-pebble truncate max-w-[200px]">
            {tour.name}
          </li>
        </ol>
      </nav>

      <main id="main-content">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-8 md:gap-11
          px-4 md:px-12 pt-10 md:pt-13 pb-12 md:pb-22 max-w-[1320px] mx-auto">

          {/* Left column */}
          <div>
            <section className="mb-10 md:mb-13" aria-labelledby="sec-about">
              <SectionTitle id="sec-about">About this Tour</SectionTitle>
              <p className="text-[0.96rem] text-stone leading-[1.88]">
                {tour.description}
              </p>
            </section>

            {tour.gallery?.length > 0 && (
              <section className="mb-10 md:mb-13" aria-labelledby="sec-gallery">
                <SectionTitle id="sec-gallery">Photo Gallery</SectionTitle>
                <PhotoGallery gallery={tour.gallery} tourName={tour.name} />
              </section>
            )}

            {tour.itinerary?.length > 0 && (
              <section className="mb-10 md:mb-13" aria-labelledby="sec-itin">
                <SectionTitle id="sec-itin">Day-by-Day Itinerary</SectionTitle>
                <Itinerary itinerary={tour.itinerary} />
              </section>
            )}

            {tour.highlights?.length > 0 && (
              <section className="mb-10 md:mb-13" aria-labelledby="sec-highlights">
                <SectionTitle id="sec-highlights">Tour Highlights</SectionTitle>
                <Highlights highlights={tour.highlights} />
              </section>
            )}

            {(tour.includes?.length > 0 || tour.excludes?.length > 0) && (
              <section aria-labelledby="sec-inc">
                <SectionTitle id="sec-inc">What&#39;s Included</SectionTitle>
                <IncludesExcludes
                  includes={tour.includes}
                  excludes={tour.excludes}
                />
              </section>
            )}
          </div>

          {/* Sidebar */}
          <BookingSidebar
            tour={tour}
            total={total}
            selectedAddons={selectedAddons}
            onToggleAddon={toggleAddon}
          />
        </div>

        {similarTours.length > 0 && <SimilarTours tours={similarTours} />}
      </main>
    </div>
  );
}